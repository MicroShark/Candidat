/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package actions;

import beans.SalonBean;
import beans.SalonMgr;
import java.util.ArrayList;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 *
 * @author user
 */
public class SalonAction extends actionAbstract{

    @Override
    public void afficher(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
                SalonMgr mgr = new SalonMgr();
                String id = request.getParameter("id");
                SalonBean bean = mgr.getElementByPrimaryKey(Integer.valueOf(id));
                request.setAttribute("SalonBean", bean);
  }

    @Override
        public boolean sauver(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        boolean returnValue = false;
        SalonMgr mgr = new SalonMgr();
        SalonBean bean = (SalonBean) form;
        
        if (!bean.getNomSalon().equals("")) {
            returnValue = true;
            mgr.saveElement((SalonBean) form);
        }
        return returnValue;
        
    }

    @Override
    public void creer(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
       
    }

    @Override
    public void supprimer(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        SalonMgr mgr = new SalonMgr();
    }

    @Override
    public void lister(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        SalonMgr mgr = new SalonMgr();
        request.setAttribute("SalonList", mgr.getAllElements());
    }

    @Override
    public void modifier(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
        SalonMgr mgr = new SalonMgr();
        mgr.removeElement((SalonBean) form);
    }
    
}
