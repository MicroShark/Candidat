/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
// Getter Setter
//clic droit  Refactor    Encapsulate Fields   cocher les cases et le codes est généré
package beans;

import java.util.Date;
import org.apache.struts.action.ActionForm;

/**
 *
 * @author user
 */
public class SalonBean extends ActionForm{

    private Integer id;
    private String nomSalon;
    private String lieuSalon;
    private Date dateDeb;
    private Date dateFin;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }
    
     public Integer setId(Integer id) {
        return id;
    }
    /**
     * @return the nomSalon
     */
    public String getNomSalon() {
        return nomSalon;
    }

    /**
     * @param nomSalon the nomSalon to set
     */
    public void setNomSalon(String nomSalon) {
        this.nomSalon = nomSalon;
    }

    /**
     * @return the lieuSalon
     */
    public String getLieuSalon() {
        return lieuSalon;
    }

    /**
     * @param lieuSalon the lieuSalon to set
     */
    public void setLieuSalon(String lieuSalon) {
        this.lieuSalon = lieuSalon;
    }

    /**
     * @return the dateDeb
     */
    public Date getDateDeb() {
        return dateDeb;
    }

    /**
     * @param dateDeb the dateDeb to set
     */
    public void setDateDeb(Date dateDeb) {
        this.dateDeb = dateDeb;
    }

    /**
     * @return the dateFin
     */
    public Date getDateFin() {
        return dateFin;
    }

    /**
     * @param dateFin the dateFin to set
     */
    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

}
