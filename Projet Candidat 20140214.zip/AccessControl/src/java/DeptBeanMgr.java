package persistance;


import org.apache.struts.action.ActionForm;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class DeptBeanMgr {
    private final SessionFactory sessionFactory;
    private final Session session;
    private final Transaction trs;

    public DeptBeanMgr() {
        sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        session = sessionFactory.openSession();
        trs = session.beginTransaction();
    }
    
    
    public java.util.Collection<DeptBean> getAllElements() {
        Criteria critere = session.createCriteria(DeptBean.class);
        java.util.Collection <DeptBean> allEmp = (java.util.Collection<DeptBean>) critere.list();        
        return allEmp;        
    }
    
    
    public void updateElement (DeptBean emp) {
        session.saveOrUpdate(emp);
        trs.commit();
    }
    
    public DeptBean getElementById(String id) {
        Criteria critere = session.createCriteria(DeptBean.class)
                .add(Restrictions.like("deptno", Integer.valueOf(id)));
        DeptBean emp = (DeptBean) critere.uniqueResult();
        return emp;
    }
            
}
