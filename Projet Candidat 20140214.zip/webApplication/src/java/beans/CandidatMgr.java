package beans;

import java.util.ArrayList;
import java.util.Date;

public class CandidatMgr implements BeanMgrInterface<CandidatBean> {

    /**
     *
     * @return
     */
    @Override
    public ArrayList<CandidatBean> getAllElements() {
        ArrayList<CandidatBean> ar = new ArrayList<>();
        CandidatBean can1 = new CandidatBean();
        CandidatBean can2 = new CandidatBean();

        // 1er candidat
        can1.setId(1);
        can1.setNom("Dupont");
        can1.setPrenom("Robert");

        Date datenaiss1 = new Date(10, 10, 2025);
        can1.setDatenaiss(datenaiss1);
        Date datepo1 = new Date(05 - 02 - 2028);
        can1.setDatepo(datepo1);

        can1.setCp("78000");
        can1.setVille("Versailles");
        can1.setAdresse("rue du projet");
        can1.setTelephone("1102030405");
        can1.setEmail("projet@gmail.com");
        can1.setNiveau("BAC");
        can1.setSpec("charbonnerie");

        // 2e candidat 
        can2.setId(2);
        can2.setNom("HUEL");
        can2.setPrenom("GEORGES");

        Date datenaiss2 = new Date(20, 04, 2012);
        can2.setDatenaiss(datenaiss2);

        can2.setCp("93000");
        can2.setVille("Bondy");
        can2.setAdresse("rue du candidat");
        can2.setTelephone("1070480911");
        can2.setEmail("pzehjet@hotmail.com");
        can2.setNiveau("MASTER");
        can2.setSpec("INFORMATIQUE");

        Date datepo2 = new Date(05, 02, 2028);
        can2.setDatepo(datepo2);

        return ar;

    }

    @Override
    public CandidatBean getElementByPrimaryKey(Integer primaryKey) {

        CandidatBean can1 = new CandidatBean();
        can1.setId(1);
        can1.setNom("robert");
        return can1;
    }

    /**
     *
     * @param element
     */
    @Override
    public void removeElement(CandidatBean element) {

    }

    @Override
    public void saveElement(CandidatBean element) {

    }

}
