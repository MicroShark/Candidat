/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class SalonMgr implements BeanMgrInterface<SalonBean> {

    @Override
    public ArrayList<SalonBean> getAllElements() {
        ArrayList<SalonBean> list = new ArrayList<>();
        // 1er Bean
        SalonBean s1 = new SalonBean();
        s1.setNomSalon("Post Bac");
        s1.setLieuSalon("Porte de Versailles");

        DateFormat format = DateFormat.getDateInstance(DateFormat.SHORT, Locale.FRANCE);
        try {
            s1.setDateDeb(format.parse("05/01/2014"));
        } catch (ParseException ex) {
            Logger.getLogger(SalonMgr.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            s1.setDateFin(format.parse("25/01/2014"));
        } catch (ParseException ex) {
            Logger.getLogger(SalonMgr.class.getName()).log(Level.SEVERE, null, ex);
        }

        list.add(s1);

        //2eme Bean
        SalonBean s2 = new SalonBean();
        s2.setNomSalon("Salon du recrutement");
        s2.setLieuSalon("La Défense");
        try {
            s2.setDateDeb(format.parse("14/06/2014"));
        } catch (ParseException ex) {
            Logger.getLogger(SalonMgr.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            s2.setDateFin(format.parse("24/06/2014"));
        } catch (ParseException ex) {
            Logger.getLogger(SalonMgr.class.getName()).log(Level.SEVERE, null, ex);
        }
        list.add(s2);
        return list;

    }

    @Override
    public SalonBean getElementByPrimaryKey(Integer primaryKey) {
        SalonBean s = new SalonBean();
        s.setNomSalon("Salon du recrutement");
        s.setLieuSalon("La Défense");
        DateFormat format = DateFormat.getDateInstance(DateFormat.SHORT, Locale.FRANCE);

        try {
            s.setDateDeb(format.parse("14/06/2014"));
        } catch (ParseException ex) {
            Logger.getLogger(SalonMgr.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            s.setDateFin(format.parse("24/06/2014"));
        } catch (ParseException ex) {
            Logger.getLogger(SalonMgr.class.getName()).log(Level.SEVERE, null, ex);
        }
        return s;
    }

    @Override
    public void removeElement(SalonBean element) {
    }

    @Override
    public void saveElement(SalonBean element) {
    }

}
