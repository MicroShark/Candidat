/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package accesscontrol.beans;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

/**
 *
 * @author User
 */
public class HibernateFactory {
    
    private final SessionFactory sessionFactory;
    private final Session session;
    private final Transaction transaction;
    
    private HibernateFactory() {
        sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        session = sessionFactory.openSession();
        transaction = session.beginTransaction();
    }
    
    public static HibernateFactory getInstance() {
        return NewSingletonHolder.INSTANCE;
    }
    
    public Transaction getTransaction() {
        return transaction;
    }

    public Session getSession() {
        return session;
    }
    
    private static class NewSingletonHolder {
        private static final HibernateFactory INSTANCE = new HibernateFactory();
    }
}
