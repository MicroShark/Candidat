/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class NiveauEtudeMgr implements BeanMgrInterface<NiveauEtudeBean> {

    @Override
    public ArrayList<NiveauEtudeBean> getAllElements() {
        ArrayList<NiveauEtudeBean> list = new ArrayList<>();
        NiveauEtudeBean a = new NiveauEtudeBean();
        a.setId(1);
        a.setNom("Baccalaureat");
        list.add(a);
        NiveauEtudeBean b = new NiveauEtudeBean();
        b.setId(2);
        b.setNom("Licence");
        list.add(b);
        return list;
    }

    @Override
    public NiveauEtudeBean getElementByPrimaryKey(Integer primaryKey) {
        NiveauEtudeBean a = new NiveauEtudeBean();
        a.setId(1);
        a.setNom("Baccalaureat");
        return a;
    }

    @Override
    public void removeElement(NiveauEtudeBean element) {

    }

    @Override
    public void saveElement(NiveauEtudeBean element) {

    }

}
