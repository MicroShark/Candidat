package persistance;

public class DeptBean {

    private Integer deptno;
    private String dname;
    private String loc;

    public DeptBean() {
    }

    public Integer getDeptno() {
        return deptno;
    }

    public void setDeptno(Integer i) {
        deptno = i;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String s) {
        dname = s;
    }

    public String getLoc() {
        return loc;
    }

    public void setLoc(String s) {
        loc = s;
    }
}
